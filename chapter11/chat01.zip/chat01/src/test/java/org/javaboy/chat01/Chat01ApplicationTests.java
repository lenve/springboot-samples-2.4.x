package org.javaboy.chat01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chat01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
